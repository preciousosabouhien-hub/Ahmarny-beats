import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowRight, Headphones, LogIn, Menu, Music2, Pause, Play, Search, ShieldCheck, ShoppingBag, UserRound, X, LayoutDashboard, LogOut, Plus, Trash2 } from 'lucide-react';
import './styles.css';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

type License={id:string;type:string;name:string;priceKobo:number;details?:string};
type Beat={id:string;title:string;slug:string;genre:string;mood?:string;bpm:number;musicalKey:string;
          description?:string;coverUrl?:string;previewUrl?:string;licenses:License[]};
type User={id:string;name:string;email:string;role:'CUSTOMER'|'ADMIN'};

const money=(k:number)=>new Intl.NumberFormat('en-NG',{style:'currency',currency:'NGN',maximumFractionDigits:0}).format(k/100);
const token=()=>localStorage.getItem('ahmarny_token');
async function api(path:string, options:RequestInit={}){const headers=new Headers(options.headers);
        if(!(options.body instanceof FormData))headers.set('Content-Type','application/json');
        const t=token();if(t)headers.set('Authorization',`Bearer ${t}`);
        const r=await fetch(`${API}${path}`,{...options,headers});
        let d:any={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.message||'Request failed');return d;}

const demo:Beat[]=[
{id:'1',title:'After Hours',slug:'after-hours',genre:'Afrobeats',mood:'Late Night',bpm:104,musicalKey:'F# Min',description:'Dark, melodic Afrobeats with warm percussion and space for a memorable hook.',coverUrl:'https://images.unsplash.com/photo-1524368535928-5b5e00ddc76b?auto=format&fit=crop&w=900&q=80',licenses:[{id:'1a',type:'MP3_LEASE',name:'MP3 Lease',priceKobo:150000},{id:'1b',type:'WAV_LEASE',name:'WAV Lease',priceKobo:250000}]},
{id:'2',title:'Lagos Nights',slug:'lagos-nights',genre:'Afro R&B',mood:'Smooth',bpm:96,musicalKey:'A Min',description:'Smooth late-night Afro R&B with lush chords and a clean pocket.',coverUrl:'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=900&q=80',licenses:[{id:'2a',type:'MP3_LEASE',name:'MP3 Lease',priceKobo:150000},{id:'2b',type:'WAV_LEASE',name:'WAV Lease',priceKobo:250000}]},
{id:'3',title:'No Pressure',slug:'no-pressure',genre:'Trap',mood:'Confident',bpm:142,musicalKey:'C# Min',description:'Hard drums, atmospheric melodies and room for confident vocals.',coverUrl:'https://images.unsplash.com/photo-1571266028243-d220c9c3bfcf?auto=format&fit=crop&w=900&q=80',licenses:[{id:'3a',type:'MP3_LEASE',name:'MP3 Lease',priceKobo:150000},{id:'3b',type:'WAV_LEASE',name:'WAV Lease',priceKobo:250000}]},
{id:'4',title:'Palm Wine',slug:'palm-wine',genre:'Afrobeats',mood:'Feel Good',bpm:110,musicalKey:'D Maj',description:'Bright guitar-led Afrobeats for summer records and feel-good releases.',coverUrl:'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=900&q=80',licenses:[{id:'4a',type:'MP3_LEASE',name:'MP3 Lease',priceKobo:150000},{id:'4b',type:'WAV_LEASE',name:'WAV Lease',priceKobo:250000}]}
];

function Header({user,onLogin,onLogout}:{user:User|null;onLogin:()=>void;onLogout:
    ()=>void}){const[open,setOpen]=useState(false);
        return <header><a className="logo" href="/">
            <span className="logoMark"><Music2 size={19}/></span>AHMARNY</a>
            <nav className={open?'open':''}><a href="/">Home</a><a href="/store">Beat Store</a>
            <a href="/#licenses">Licensing</a><a href="/#about">About</a>
            {user?<><a href={user.role==='ADMIN'?'/admin':'/account'}>
            {user.role==='ADMIN'?<><LayoutDashboard size={15}/> Dashboard</>:<><UserRound size={15}/> Account</>}
            </a><button className="navBtn" onClick={onLogout}><LogOut size={15}/> Logout</button></>:
            <button className="navBtn" onClick={onLogin}><LogIn size={15}/> Login</button>}</nav>
            <div className="headerActions"><a href="/store" aria-label="Store"><ShoppingBag size={19}/></a>
            <button className="hamb" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></div></header>}

function Auth({mode,onClose,onSuccess}:{mode:'login'|'register';onClose:()=>void;onSuccess:(u:User)=>void})
{const[login,setLogin]=useState(mode==='login');const[form,setForm]=useState({name:'',email:'',password:''});
const[error,setError]=useState('');async function submit(e:React.FormEvent){e.preventDefault();setError('');
    try{const d=await api(`/auth/${login?'login':'register'}`,{method:'POST',body:JSON.stringify(form)});
    localStorage.setItem('ahmarny_token',d.token);onSuccess(d.user);onClose()}catch(err:any){setError(err.message)}}
    return <div className="modalBackdrop"><div className="modal"><button className="close" onClick={onClose}>×</button>
    <p className="eyebrow">{login?'WELCOME BACK':'JOIN AHMARNY'}</p>
    <h2>{login?'Sign in to your account.':'Create your account.'}</h2>
    {error&&<div className="error">{error}</div>}<form onSubmit={submit}>
        {!login&&<input placeholder="Full name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/>}
        <input type="email" placeholder="Email address" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/>
        <input type="password" placeholder="Password (8+ characters)" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} minLength={8} required/>
        <button className="checkout">{login?'Sign in':'Create account'} <ArrowRight size={16}/></button></form>
        <button className="switch" onClick={()=>{setLogin(!login);setError('')}}>{login?'Need an account? Create one':'Already have an account? Sign in'}</button>
        </div></div>}

function BeatCard({b,onAdd}:{b:Beat;onAdd:(b:Beat,l:License)=>void})
{const[playing,setPlaying]=useState(false);const[license,setLicense]=useState(b.licenses[0]);
    const audio=React.useRef<HTMLAudioElement|null>(null);
    useEffect(()=>{setLicense(b.licenses[0]);setPlaying(false)},[b.id]);
    async function togglePreview(){if(!b.previewUrl||!audio.current)return;
        if(playing){audio.current.pause();setPlaying(false);return}try{await audio.current.play();
            setPlaying(true)}catch{setPlaying(false)}}return <article className="beat">
                <div className="cover">
                    <img src={b.coverUrl||'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=900&q=80'} alt={b.title}/>
                    {b.previewUrl&&<audio ref={audio} src={b.previewUrl} onEnded={()=>setPlaying(false)} preload="none"/>}<button className="play" disabled={!b.previewUrl} title={b.previewUrl?'Play preview':'No preview uploaded'} onClick={togglePreview}>{playing?<Pause size={19}/>:<Play size={19}/>}</button><span className="tag">{b.genre}</span></div><div className="beatInfo"><div><h3>{b.title}</h3><p>{b.bpm} BPM • {b.musicalKey}</p></div><strong>{money(license?.priceKobo||0)}</strong></div>{b.licenses?.length>0&&<select value={license?.id||''} onChange={e=>setLicense(b.licenses.find(x=>x.id===e.target.value)||b.licenses[0])}>{b.licenses.map(l=><option key={l.id} value={l.id}>{l.name} — {money(l.priceKobo)}</option>)}</select>}<button className="add" disabled={!license} onClick={()=>license&&onAdd(b,license)}>Add to cart <ArrowRight size={16}/></button></article>}

function Store({user,onLogin}:{user:User|null;onLogin:()=>void}){const[beats,setBeats]=useState<Beat[]>(demo);const[q,setQ]=useState('');
    const[genre,setGenre]=useState('All');const[cart,setCart]=useState<{beat:Beat;license:License}[]>([]);const[message,setMessage]=useState('');
    useEffect(()=>{api('/beats').then(x=>x.length&&setBeats(x)).catch(()=>{})},[]);const genres=['All',...Array.from(new Set(beats.map(b=>b.genre)))];
    const filtered=useMemo(()=>beats.filter(b=>(genre==='All'||b.genre===genre)&&(!q||`${b.title} ${b.genre} ${b.mood||''}`.toLowerCase().includes(q.toLowerCase()))),
    [beats,q,genre]);const total=cart.reduce((s,x)=>s+x.license.priceKobo,0);function add(b:Beat,l:License){setCart(c=>[...c,{beat:b,license:l}]);
    setMessage(`${b.title} added to cart`)}async function checkout(){if(!user){onLogin();
        return}try{await api('/orders',{method:'POST',body:JSON.stringify({email:user.email,customerName:user.name,items:cart.map(x=>({beatId:x.beat.id,licenseId:x.license.id}))})});
        setMessage('Order created. Paystack checkout will open once production keys are configured.')}catch(e:any){setMessage(e.message)}}return <>
        <Header user={user} onLogin={onLogin} onLogout={()=>{localStorage.removeItem('ahmarny_token');location.href='/'}}/><main><section className="storeHero">
            <p className="eyebrow">AHMARNY BEAT STORE</p><h1>Find the beat<br/><em>for your record.</em></h1>
            <p>Browse, preview and license original instrumentals. Your purchases stay in your account.</p></section>
            <section className="section"><div className="sectionHead"><div><p className="eyebrow">THE CATALOG</p>
            <h2>{beats.length} beats available.</h2></div><div className="search"><Search size={18}/>
            <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search beats..."/></div></div>
            <div className="filters">{genres.map(g=><button key={g} className={genre===g?'active':''} onClick={()=>setGenre(g)}>{g}</button>)}</div>
            <div className="grid">{filtered.map(b=><BeatCard key={b.id} b={b} onAdd={add}/>)}</div></section><section className="cart"><div>
                <p className="eyebrow">YOUR CART</p><h2>{cart.length?'Ready to checkout?':'Your cart is waiting.'}</h2></div>
                {cart.length?<div className="cartBox">{cart.map((x,i)=><div className="cartLine" key={i}><span><b>{x.beat.title}</b>
                <small>{x.license.name}</small></span><strong>{money(x.license.priceKobo)}</strong><button onClick={()=>setCart(c=>c.filter((_,j)=>j!==i))}>×</button></div>)}
                <div className="total"><span>Total</span><strong>{money(total)}</strong></div>
                <button className="checkout" onClick={checkout}>Continue to secure checkout <ArrowRight/></button>
                </div>:<p className="empty">Select a licence and add a beat to your cart.</p>}</section></main>
                {message&&<div className="toast">{message}<button onClick={()=>setMessage('')}>×</button></div>}</>}

function Landing({user,onLogin}:{user:User|null;onLogin:()=>void}){return <><Header user={user} onLogin={onLogin} onLogout={()=>{localStorage.removeItem('ahmarny_token');location.href='/'}}/><main><section className="hero"><div className="heroCopy"><p className="eyebrow">THE AHMARNY SOUND</p><h1>Beats that make<br/><em>records.</em></h1><p className="lead">Premium instrumentals built for artists who want a sound that feels expensive from the first bar.</p><div className="heroBtns"><a className="primary" href="/store">Explore beat store <ArrowRight size={18}/></a><a className="secondary" href="#licenses">View licences</a></div><div className="proof"><span><strong>100+</strong> original beats</span><span><strong>4</strong> flexible licences</span><span><strong>24/7</strong> instant delivery</span></div></div><div className="heroVisual"><div className="record"><div className="recordCenter">A</div></div><div className="floatCard"><Headphones size={17}/><span><b>Studio ready</b><small>WAV • stems • MP3</small></span></div></div></section><section id="licenses" className="section dark"><div className="center"><p className="eyebrow">LICENSING</p><h2>Choose the rights<br/>your record needs.</h2><p>Clear licensing, studio quality and instant delivery.</p></div><div className="licenseGrid">{[['MP3 Lease','₦15k','For demos and emerging releases'],['WAV Lease','₦25k','For serious releases'],['Trackout','₦50k','For mixing and mastering'],['Exclusive','₦150k','For exclusive use']].map((x,i)=><div className={i===3?'license featured':'license'} key={x[0]}><span>0{i+1}</span><h3>{x[0]}</h3><strong>{x[1]}</strong><p>{x[2]}</p><a href="/store">Choose licence <ArrowRight size={15}/></a></div>)}</div></section><section id="about" className="about"><div><p className="eyebrow">WHY AHMARNY</p><h2>Less searching.<br/>More creating.</h2></div><div className="aboutText"><p>Ahmarny is a producer-first beat store built around one idea: the right instrumental should make you want to write immediately.</p><div className="points"><span><ShieldCheck/>Clear licensing</span><span><Headphones/>Studio quality</span><span><ArrowRight/>Instant delivery</span></div></div></section></main></>}

function Account({user}:{user:User}){return <><Header user={user} onLogin={()=>{}} onLogout={()=>{localStorage.removeItem('ahmarny_token');location.href='/'}}/><main className="accountPage"><p className="eyebrow">MY AHMARNY</p><h1>Welcome, {user.name}.</h1><div className="accountCard"><UserRound/><div><h3>{user.email}</h3><p>Your customer account is connected to the Ahmarny API. Your future purchases and licences will appear here.</p></div></div><a className="primary" href="/store">Browse beats <ArrowRight size={18}/></a></main></>}

function Admin({user}:{user:User}){
 const[stats,setStats]=useState<any>(null);const[beats,setBeats]=useState<Beat[]>([]);const[error,setError]=useState('');const[notice,setNotice]=useState('');const[busy,setBusy]=useState(false);const[audioFile,setAudioFile]=useState<File|null>(null);const[coverFile,setCoverFile]=useState<File|null>(null);
 const[form,setForm]=useState({title:'',slug:'',genre:'Afrobeats',mood:'',bpm:'100',musicalKey:'C Min',description:'',coverUrl:'',previewUrl:''});
 async function load(){try{const[s,b]=await Promise.all([api('/admin/stats'),api('/beats')]);setStats(s);setBeats(b)}catch(e:any){setError(e.message)}}useEffect(()=>{load()},[]);
 async function uploadFile(file:File,kind:'audio'|'cover'){const body=new FormData();body.append('file',file);const result=await api(`/admin/uploads/${kind}`,{method:'POST',body});return result.url as string}
 async function create(e:React.FormEvent){e.preventDefault();setError('');setNotice('');setBusy(true);try{let previewUrl=form.previewUrl;let coverUrl=form.coverUrl;if(audioFile)previewUrl=await uploadFile(audioFile,'audio');if(coverFile)coverUrl=await uploadFile(coverFile,'cover');if(!previewUrl)throw new Error('Upload an MP3/WAV file or provide an audio preview URL.');await api('/admin/beats',{method:'POST',body:JSON.stringify({...form,previewUrl,coverUrl})});setForm({title:'',slug:'',genre:'Afrobeats',mood:'',bpm:'100',musicalKey:'C Min',description:'',coverUrl:'',previewUrl:''});setAudioFile(null);setCoverFile(null);const audioInput=document.getElementById('beat-audio') as HTMLInputElement|null;if(audioInput)audioInput.value='';const coverInput=document.getElementById('beat-cover') as HTMLInputElement|null;if(coverInput)coverInput.value='';setNotice('Beat uploaded and published to the store.');await load()}catch(e:any){setError(e.message||'Could not upload beat')}finally{setBusy(false)}}
 async function del(id:string){if(!confirm('Delete this beat?'))return;try{await api(`/admin/beats/${id}`,{method:'DELETE'});await load()}catch(e:any){setError(e.message)}}
 return <><Header user={user} onLogin={()=>{}} onLogout={()=>{localStorage.removeItem('ahmarny_token');location.href='/'}}/><main className="adminPage"><div className="adminTop"><div><p className="eyebrow">ADMIN</p><h1>Ahmarny Dashboard</h1></div><a className="secondary" href="/store">View store</a></div>{error&&<div className="error">{error}</div>}{notice&&<div className="uploadNotice">{notice}</div>}<div className="stats">{[['Users',stats?.users??'—'],['Beats',stats?.beats??'—'],['Orders',stats?.orders??'—'],['Revenue',stats?money(stats.revenueKobo):'—']].map(x=><div className="stat" key={x[0]}><small>{x[0]}</small><strong>{x[1]}</strong></div>)}</div><div className="adminGrid"><section className="adminCard"><h2>Upload a beat</h2><p className="adminHint">Add the audio file and details. Published beats appear in the public store.</p><form onSubmit={create}><label className="fileLabel" htmlFor="beat-audio">Preview audio <span>MP3 or WAV · max 30 MB</span></label><input id="beat-audio" type="file" accept=".mp3,.wav,audio/mpeg,audio/wav" onChange={e=>setAudioFile(e.target.files?.[0]||null)} required/><small className="selectedFile">{audioFile?`Selected: ${audioFile.name}`:'Use a watermarked preview only; this file is publicly playable.'}</small><label className="fileLabel" htmlFor="beat-cover">Cover artwork <span>JPG, PNG or WebP · optional</span></label><input id="beat-cover" type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setCoverFile(e.target.files?.[0]||null)}/><input placeholder="Beat title" value={form.title} onChange={e=>setForm({...form,title:e.target.value,slug:e.target.value.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')})} required/><input placeholder="Genre" value={form.genre} onChange={e=>setForm({...form,genre:e.target.value})} required/><div className="two"><input placeholder="BPM" type="number" min="1" max="400" value={form.bpm} onChange={e=>setForm({...form,bpm:e.target.value})} required/><input placeholder="Musical key" value={form.musicalKey} onChange={e=>setForm({...form,musicalKey:e.target.value})} required/></div><input placeholder="Mood (optional)" value={form.mood} onChange={e=>setForm({...form,mood:e.target.value})}/><textarea placeholder="Description (optional)" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/><button className="checkout" disabled={busy}>{busy?'Uploading beat…':<><Plus size={16}/> Upload and publish beat</>}</button></form></section><section className="adminCard"><h2>Beat catalogue</h2>{beats.map(b=><div className="adminBeat" key={b.id}><div><b>{b.title}</b><small>{b.genre} • {b.bpm} BPM {b.previewUrl?'• Audio uploaded':'• No audio'}</small></div><button aria-label={`Delete ${b.title}`} onClick={()=>del(b.id)}><Trash2 size={16}/></button></div>)}</section></div></main></>}

function App(){const[path,setPath]=useState(location.pathname);const[user,setUser]=useState<User|null>(null);const[auth,setAuth]=useState(false);useEffect(()=>{const fn=()=>setPath(location.pathname);window.addEventListener('popstate',fn);const t=token();if(t)api('/auth/me').then(d=>setUser(d.user)).catch(()=>localStorage.removeItem('ahmarny_token'));return()=>window.removeEventListener('popstate',fn)},[]);useEffect(()=>{document.querySelectorAll('a[href^="/"]').forEach(a=>a.addEventListener('click',e=>{const href=(a as HTMLAnchorElement).getAttribute('href')!;if(href.startsWith('/#'))return;e.preventDefault();history.pushState({},'',href);setPath(href) }))},[path]);const login=()=>setAuth(true);let content=path==='/store'?<Store user={user} onLogin={login}/>:path==='/account'?(user?<Account user={user}/>:<Landing user={user} onLogin={login}/>):path==='/admin'?(user?.role==='ADMIN'?<Admin user={user}/>:<Landing user={user} onLogin={login}/>):<Landing user={user} onLogin={login}/>;return <>{content}{auth&&<Auth mode="login" onClose={()=>setAuth(false)} onSuccess={u=>{setUser(u);if(u.role==='ADMIN'){history.pushState({},'', '/admin');setPath('/admin')}else{history.pushState({},'', '/account');setPath('/account')}}}/>}</>}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
